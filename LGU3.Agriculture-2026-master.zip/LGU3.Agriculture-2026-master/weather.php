<?php
// Weather search bar + result container only
?>
<div class="weather-search">
  <input type="text" id="city" placeholder="Enter city name...">
  <button onclick="getForecast()">Get Forecast</button>
</div>
<div id="weather-result"></div>