<h2>Key Features</h2>
<ul>
  <li>📊 Predictive analytics for rice yield forecasting</li>
  <li>🐛 Pest detection and management strategies</li>
  <li>🌱 Data visualization dashboards for easy interpretation</li>
  <li>🤖 AI-driven Assistant for farming guidance</li>
  <li>☁️ Integrated weather forecasting to support agricultural planning</li>
</ul>
