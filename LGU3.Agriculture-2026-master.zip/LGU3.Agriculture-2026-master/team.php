<h2>Meet the Team</h2>
<p>
  Our team is composed of dedicated students and mentors from Local Government Unit 3, 
  working together to harness AI for agriculture. Each member contributes expertise in 
  software development, data science, and agricultural research to ensure the project’s 
  success.
</p>
<ul>
  <li> Emerson R. Bustamante – Lead Developer</li>
  <li> Lord Zyrill John M. David – Network Administrator</li>
  <li> Jan Juspher N. Martinez – Document Analyst </li>
  <li> Roel V. Ojascastro – Network Administrator</li>
  <li> Rico E. Perodes – Assistant Programmer</li>
</ul>