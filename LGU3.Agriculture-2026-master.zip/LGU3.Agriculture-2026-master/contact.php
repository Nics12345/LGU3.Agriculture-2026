<h2>Contact Us</h2>
<p>
  📍 Local Government Unit 3<br>
  📧 Email: <a href="mailto:info@lgu3-riceai.com">lgu3.agriculture@gmail.com</a><br>
  ☎ Phone: +63 993 360 8400
</p>
<p>
  For inquiries about the AI-powered rice yield forecasting and pest management project, 
  please reach out to us. We welcome collaboration, feedback, and opportunities to 
  expand the impact of this initiative.
</p>